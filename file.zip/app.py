#!/usr/bin/env python3
"""
MRARFAI 销售分析 Dashboard v3.2 — 部署就绪版
==============================================
Week 5-6: 错误处理 · 反馈收集 · 部署配置 · 使用日志
运行：streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import json, os, tempfile
from datetime import datetime

try:
    import plotly.graph_objects as go
    import plotly.express as px
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from analyze_clients_v2 import SprocommDataLoaderV2, DeepAnalyzer, ReportGeneratorV2
from industry_benchmark import IndustryBenchmark, generate_benchmark_section
from forecast_engine import ForecastEngine, generate_forecast_section
from ai_narrator import AINarrator, generate_narrative_section
from feedback_collector import save_feedback, load_all_feedback, get_summary, log_usage

MONTHS = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
VERSION = "3.2"

# Plotly暗色模板
PLOT_BG = "rgba(15,15,35,0)"
PAPER_BG = "rgba(15,15,35,0)"
GRID_COLOR = "rgba(100,100,180,0.15)"
CYAN = "#00d4ff"
RED = "#ff4466"
GREEN = "#00cc66"
ORANGE = "#ffaa00"
PURPLE = "#7c3aed"
COLORS = [CYAN, GREEN, ORANGE, PURPLE, RED, "#ff88cc", "#44ddaa", "#ffcc44"]

def plotly_layout(title="", height=400, showlegend=True):
    """统一的Plotly布局"""
    return dict(
        title=dict(text=title, font=dict(size=15, color="#ccccee"), x=0),
        paper_bgcolor=PAPER_BG,
        plot_bgcolor=PLOT_BG,
        font=dict(color="#aaaacc", size=12),
        height=height,
        showlegend=showlegend,
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
        margin=dict(l=50, r=20, t=40, b=40),
        xaxis=dict(gridcolor=GRID_COLOR, showgrid=True, tickfont=dict(size=11)),
        yaxis=dict(gridcolor=GRID_COLOR, showgrid=True, tickfont=dict(size=11)),
    )

def fmt(v, unit="万"):
    """格式化数字"""
    if v is None: return "-"
    try:
        v = float(v)
        if abs(v) >= 10000: return f"{v:,.0f}{unit}"
        elif abs(v) >= 100: return f"{v:,.0f}{unit}"
        elif abs(v) >= 1: return f"{v:,.1f}{unit}"
        else: return f"{v:.2f}{unit}"
    except: return str(v)

st.set_page_config(page_title="MRARFAI 销售分析", page_icon="📊", layout="wide")

# ============================================================
# 样式 — 全面升级
# ============================================================
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    .block-container { padding-top: 1.2rem; max-width: 1400px; }
    
    /* 指标卡片 */
    div[data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(15,15,35,0.9) 0%, rgba(26,26,62,0.9) 100%);
        padding: 18px 22px; border-radius: 12px;
        border: 1px solid rgba(0,212,255,0.15);
        backdrop-filter: blur(10px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.05);
        transition: transform 0.2s, box-shadow 0.2s;
    }
    div[data-testid="stMetric"]:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 25px rgba(0,212,255,0.15), inset 0 1px 0 rgba(255,255,255,0.05);
    }
    div[data-testid="stMetric"] label { 
        color: #8888bb !important; font-size: 0.85rem; letter-spacing: 0.5px;
    }
    div[data-testid="stMetric"] [data-testid="stMetricValue"] { 
        color: #00d4ff !important; font-weight: 700; font-size: 1.8rem;
    }
    div[data-testid="stMetric"] [data-testid="stMetricDelta"] { font-size: 0.85rem; }
    
    /* 侧边栏 */
    section[data-testid="stSidebar"] { 
        background: linear-gradient(180deg, #0a0a1a 0%, #0f0f2d 100%);
        border-right: 1px solid rgba(0,212,255,0.1);
    }
    section[data-testid="stSidebar"] * { color: #ccccee; }
    
    /* Tab 标签 */
    .stTabs [data-baseweb="tab-list"] { gap: 4px; }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px 8px 0 0; padding: 8px 16px;
        font-size: 0.85rem;
    }
    
    /* 表格 */
    .stDataFrame { border-radius: 10px; overflow: hidden; }
    
    /* Expander */
    .streamlit-expanderHeader { 
        font-weight: 600; font-size: 0.95rem; 
        border-radius: 8px;
    }
    
    /* 分隔线 */
    hr { border-color: rgba(100,100,180,0.2) !important; margin: 1.5rem 0 !important; }
    
    /* 自定义卡片 */
    .insight-card {
        background: linear-gradient(135deg, rgba(0,212,255,0.08), rgba(124,58,237,0.05));
        border: 1px solid rgba(0,212,255,0.15);
        border-radius: 12px; padding: 16px 20px; margin: 8px 0;
    }
    .insight-card h4 { color: #00d4ff; margin: 0 0 8px 0; font-size: 0.95rem; }
    .insight-card p { color: #ccccee; margin: 0; font-size: 0.88rem; line-height: 1.6; }
    
    .risk-badge {
        display: inline-block; padding: 3px 10px; border-radius: 12px;
        font-size: 0.78rem; font-weight: 600;
    }
    .risk-high { background: rgba(255,68,102,0.2); color: #ff4466; }
    .risk-med { background: rgba(255,170,0,0.2); color: #ffaa00; }
    .risk-low { background: rgba(0,204,102,0.2); color: #00cc66; }
</style>
""", unsafe_allow_html=True)

# ============================================================
# 侧边栏
# ============================================================
with st.sidebar:
    st.markdown("### 📊 MRARFAI")
    st.markdown("**销售分析 Agent v3.2**")
    st.caption("Sprocomm 禾苗通讯 | 01401.HK")
    st.divider()
    
    st.markdown("##### 📁 数据上传")
    rev_file = st.file_uploader("金额报表 (.xlsx)", type=['xlsx'], key='rev')
    qty_file = st.file_uploader("数量报表 (.xlsx)", type=['xlsx'], key='qty')
    
    st.divider()
    st.markdown("##### 🤖 AI 设置")
    ai_enabled = st.toggle("启用 AI 深度叙事", value=False)
    if ai_enabled:
        ai_provider = st.selectbox("模型", ['DeepSeek', 'Claude'])
        api_key = st.text_input("API Key", type="password")
    else:
        ai_provider, api_key = 'Claude', None
    
    st.divider()
    st.markdown("""
    <div style="text-align:center; opacity:0.5; font-size:0.75rem; padding:10px 0;">
        <div>Powered by MRARFAI</div>
        <div style="margin-top:4px;">© 2025 版权所有</div>
    </div>
    """, unsafe_allow_html=True)

# ============================================================
# 主标题
# ============================================================
st.markdown("""
<div style="display:flex; align-items:center; gap:12px; margin-bottom:-10px;">
    <div style="font-size:2.2rem;">🏢</div>
    <div>
        <h1 style="margin:0; font-size:1.9rem; color:#eeeeee;">禾苗通讯 销售深度分析</h1>
        <p style="margin:0; color:#7777aa; font-size:0.9rem;">12维度分析 · 行业对标 · 预测引擎 · AI战略叙事</p>
    </div>
</div>
""", unsafe_allow_html=True)
st.markdown("")

if not rev_file or not qty_file:
    st.info("👈 请在左侧上传金额报表和数量报表")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div class="insight-card">
            <h4>📊 深度分析</h4>
            <p>客户ABC分级 · 价量分解 · 流失预警 · 异常检测 · 区域集中度</p>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="insight-card">
            <h4>🌐 行业对标</h4>
            <p>华勤/闻泰/龙旗对比 · HMD外部情报 · 结构性风险 · 战略机会</p>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div class="insight-card">
            <h4>🔮 前瞻预测</h4>
            <p>Q1 2026营收预测 · 客户级别预测 · 4种情景分析 · CEO行动建议</p>
        </div>
        """, unsafe_allow_html=True)
    
    # 使用指南
    st.divider()
    st.markdown("### 📖 快速使用指南")
    st.markdown("""
    **第一步**：准备两份Excel文件
    - **金额报表**：包含Sheet `2025数据`（客户月度出货金额）、`Sheet2`（类别YoY）、`Sheet3`（区域分布）等
    - **数量报表**：包含Sheet `数量汇总`（客户月度出货数量、产品类型、订单模式）
    
    **第二步**：在左侧上传文件 → 系统自动运行12维度分析
    
    **第三步**：浏览各Tab查看分析结果，在「导出」Tab下载完整报告
    """)
    
    with st.expander("❓ 常见问题"):
        st.markdown("""
        **Q: 数据安全吗？**  
        A: 所有数据仅在当前会话中处理，不保存到服务器，会话结束后自动清除。
        
        **Q: 支持什么格式？**  
        A: 仅支持 `.xlsx` 格式。请确保Sheet名称与模板一致。
        
        **Q: 分析需要多久？**  
        A: 通常10-30秒完成全套分析（取决于数据量）。
        """)
    
    st.stop()

# ============================================================
# 数据加载 + 全套分析
# ============================================================
@st.cache_data(show_spinner=False)
def run_full_analysis(rev_bytes, qty_bytes):
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f1:
        f1.write(rev_bytes); rp = f1.name
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f2:
        f2.write(qty_bytes); qp = f2.name
    try:
        loader = SprocommDataLoaderV2(rp, qp)
        data = loader.load_all()
        analyzer = DeepAnalyzer(data)
        results = analyzer.run_all()
        bench = IndustryBenchmark(data, results).run()
        forecast = ForecastEngine(data, results).run()
        return data, results, bench, forecast, None
    except Exception as e:
        return None, None, None, None, str(e)
    finally:
        try:
            os.unlink(rp); os.unlink(qp)
        except:
            pass

with st.spinner("🔄 数据加载 + 深度分析中..."):
    data, results, benchmark, forecast, error = run_full_analysis(rev_file.read(), qty_file.read())

if error:
    st.error(f"❌ 数据加载失败：{error}")
    st.markdown("""
    **可能原因：**
    - Excel文件格式不符合预期（Sheet名称不对）
    - 数据行列位置与模板不匹配
    - 文件损坏或加密
    
    请检查文件后重新上传。如问题持续，请联系开发者。
    """)
    st.stop()

st.success(f"✅ v{VERSION} 全套分析完成", icon="🎯")
log_usage('analysis_complete', f"营收={data['总营收']:.0f}")

# ============================================================
# Tab 导航
# ============================================================
tabs = st.tabs([
    "📊 总览", "👥 客户分析", "💰 价量分解", "🚨 预警中心",
    "📈 增长机会", "🏭 产品结构", "🌍 区域分析",
    "🌐 行业对标", "🔮 预测", "✍️ CEO备忘录", "📥 导出", "💬 反馈",
])

# ============================================================
# Tab 0: 总览
# ============================================================
with tabs[0]:
    yoy = data['总YoY']
    qs = data['数量汇总']
    active = sum(1 for c in data['客户金额'] if c['年度金额'] > 0)
    high_risk = [a for a in results['流失预警'] if '高' in a['风险']]
    hr_amt = sum(a['年度金额'] for a in high_risk)

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("全年营收", f"{data['总营收']:,.0f}万", f"+{yoy['增长率']*100:.1f}% YoY")
    c2.metric("出货数量", f"{qs['全年实际']/10000:,.0f}万台", f"完成率{qs['全年实际']/qs['全年计划']*100:.0f}%")
    c3.metric("活跃客户", f"{active}家")
    c4.metric("高风险预警", f"{len(high_risk)}家", f"{hr_amt:,.0f}万")
    c5.metric("增长机会", f"{len(results['增长机会'])}个")

    st.divider()
    
    # 核心发现 — 卡片式
    st.subheader("🔍 核心发现")
    findings = results['核心发现']
    fcols = st.columns(min(len(findings), 3))
    for i, f in enumerate(findings):
        with fcols[i % len(fcols)]:
            st.markdown(f"""<div class="insight-card"><p>{f}</p></div>""", unsafe_allow_html=True)

    st.divider()

    # 月度营收 — Plotly
    m_data = data['月度总营收']
    col1, col2 = st.columns(2)
    
    with col1:
        if HAS_PLOTLY:
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=MONTHS, y=m_data, name="月度营收",
                marker=dict(
                    color=[CYAN if v == max(m_data) else "rgba(0,212,255,0.5)" for v in m_data],
                    line=dict(width=0),
                ),
                text=[f"{v:,.0f}" for v in m_data], textposition="outside",
                textfont=dict(size=10, color="#aaaacc"),
            ))
            fig.update_layout(**plotly_layout("月度营收趋势（万元）", 380, False))
            fig.update_yaxes(title_text="万元")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.subheader("月度营收趋势")
            st.bar_chart(pd.DataFrame({'月份': MONTHS, '金额(万元)': m_data}).set_index('月份'), color=CYAN)

    with col2:
        if HAS_PLOTLY:
            cat_data = results['类别趋势']
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=[c['类别'] for c in cat_data], y=[c['2025金额'] for c in cat_data],
                name="2025", marker_color=CYAN, text=[f"{c['2025金额']:,.0f}" for c in cat_data],
                textposition="outside", textfont=dict(size=10),
            ))
            fig.add_trace(go.Bar(
                x=[c['类别'] for c in cat_data], y=[c['2024金额'] for c in cat_data],
                name="2024", marker_color="rgba(100,100,180,0.4)",
            ))
            fig.update_layout(**plotly_layout("业务类别 YoY 对比", 380), barmode='group')
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.subheader("业务类别 YoY")
            cat_df = pd.DataFrame(results['类别趋势'])[['类别','2025金额','2024金额']]
            st.bar_chart(cat_df.set_index('类别'))

    # 季度
    q = [sum(m_data[i:i+3]) for i in range(0, 12, 3)]
    qc1, qc2, qc3, qc4 = st.columns(4)
    qc1.metric("Q1", f"{q[0]:,.0f}")
    qc2.metric("Q2", f"{q[1]:,.0f}")
    qc3.metric("Q3", f"{q[2]:,.0f}", "峰值季度")
    qc4.metric("Q4", f"{q[3]:,.0f}", f"{(q[3]/q[2]-1)*100:+.1f}%")

    # 类别明细
    st.subheader("业务类别同比明细")
    cat_df = pd.DataFrame(results['类别趋势'])
    for col in ['2025金额', '2024金额', '增长额']:
        if col in cat_df.columns:
            cat_df[col] = cat_df[col].apply(lambda x: round(float(x)) if pd.notna(x) else 0)
    st.dataframe(cat_df, use_container_width=True, hide_index=True,
        column_config={
            '2025金额': st.column_config.NumberColumn(format="%,d"),
            '2024金额': st.column_config.NumberColumn(format="%,d"),
            '增长额': st.column_config.NumberColumn(format="%,d"),
        })

# ============================================================
# Tab 1: 客户分析
# ============================================================
with tabs[1]:
    tiers = results['客户分级']
    tier_counts = {t: sum(1 for x in tiers if x['等级']==t) for t in ['A','B','C']}
    tier_rev = {t: sum(x['年度金额'] for x in tiers if x['等级']==t) for t in ['A','B','C']}

    c1, c2, c3, c4 = st.columns(4)
    c1.metric(f"A级（{tier_counts['A']}家）", f"{tier_rev['A']:,.0f}万", f"{tier_rev['A']/data['总营收']*100:.1f}%")
    c2.metric(f"B级（{tier_counts['B']}家）", f"{tier_rev['B']:,.0f}万")
    c3.metric(f"C级（{tier_counts['C']}家）", f"{tier_rev['C']:,.0f}万")
    c4.metric("Top4集中度", f"{tiers[3]['累计占比']}%", "⚠️>50%" if tiers[3]['累计占比']>50 else "✅健康")

    filter_tier = st.multiselect("筛选等级", ['A','B','C'], default=['A','B','C'])
    filtered = [t for t in tiers if t['等级'] in filter_tier]
    
    tier_df = pd.DataFrame(filtered)
    for col in ['年度金额', 'H1', 'H2']:
        if col in tier_df.columns:
            tier_df[col] = tier_df[col].apply(lambda x: round(float(x)) if pd.notna(x) else 0)
    st.dataframe(tier_df, use_container_width=True, hide_index=True,
        column_config={
            '年度金额': st.column_config.NumberColumn(format="%,d"),
            'H1': st.column_config.NumberColumn(format="%,d"),
            'H2': st.column_config.NumberColumn(format="%,d"),
        })

    # 集中度曲线
    st.subheader("客户集中度曲线")
    if HAS_PLOTLY:
        top15 = tiers[:15]
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=[t['客户'] for t in top15], y=[t['累计占比'] for t in top15],
            mode='lines+markers+text',
            text=[f"{t['累计占比']}%" for t in top15],
            textposition="top center", textfont=dict(size=9),
            line=dict(color=CYAN, width=2),
            marker=dict(size=8, color=CYAN, line=dict(width=1, color='white')),
        ))
        fig.add_hline(y=80, line_dash="dash", line_color=ORANGE,
                      annotation_text="80%线", annotation_position="right")
        fig.update_layout(**plotly_layout("Top15客户累计营收占比", 350, False))
        fig.update_yaxes(title_text="累计占比 %", range=[0, 105])
        st.plotly_chart(fig, use_container_width=True)
    else:
        cum_df = pd.DataFrame({
            '客户': [t['客户'] for t in tiers[:15]],
            '累计占比%': [t['累计占比'] for t in tiers[:15]],
        }).set_index('客户')
        st.line_chart(cum_df)

    # 单客户月度趋势
    st.divider()
    st.subheader("单客户月度趋势")
    selected = st.selectbox("选择客户", [t['客户'] for t in tiers[:20]])
    sel_data = next((c for c in data['客户金额'] if c['客户'] == selected), None)
    if sel_data:
        if HAS_PLOTLY:
            fig = go.Figure()
            vals = sel_data['月度金额']
            fig.add_trace(go.Bar(
                x=MONTHS, y=vals, marker_color=CYAN,
                text=[f"{v:,.0f}" for v in vals], textposition="outside",
                textfont=dict(size=10),
            ))
            fig.update_layout(**plotly_layout(f"{selected} 月度营收（万元）", 350, False))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.bar_chart(pd.DataFrame({'月份': MONTHS, '金额': sel_data['月度金额']}).set_index('月份'), color=CYAN)

# ============================================================
# Tab 2: 价量分解
# ============================================================
with tabs[2]:
    st.subheader("💰 价量分解")
    st.caption("单价 = 出货金额 ÷ 出货数量 → 判断增长质量")

    pv = results['价量分解']
    if not pv:
        st.warning("无法计算（需要金额+数量匹配）")
    else:
        quality_map = {}
        for p in pv:
            q = p['质量评估']
            if '优质' in q: k = '✅ 优质增长'
            elif '以价补量' in q: k = '⚠️ 以价补量'
            elif '量换价' in q: k = '⚠️ 以量换价'
            elif '齐跌' in q: k = '❌ 量价齐跌'
            else: k = '→ 价格稳定'
            quality_map[k] = quality_map.get(k, 0) + 1

        cols = st.columns(len(quality_map))
        for i, (k, v) in enumerate(quality_map.items()):
            cols[i].metric(k, f"{v}家")

        st.divider()
        
        # 修复数字格式 — 关键修复
        pv_df = pd.DataFrame(pv)
        num_cols = ['年度金额', '年度数量', '均价(元)', 'H1均价', 'H2均价']
        for col in num_cols:
            if col in pv_df.columns:
                pv_df[col] = pd.to_numeric(pv_df[col], errors='coerce').round(1)
        
        display_cols = [c for c in ['客户','年度金额','年度数量','均价(元)','H1均价','H2均价','价格变动','质量评估'] if c in pv_df.columns]
        st.dataframe(pv_df[display_cols], use_container_width=True, hide_index=True,
            column_config={
                '年度金额': st.column_config.NumberColumn(format="%,.0f"),
                '年度数量': st.column_config.NumberColumn(format="%,.0f"),
                '均价(元)': st.column_config.NumberColumn(format="%,.1f"),
                'H1均价': st.column_config.NumberColumn(format="%,.1f"),
                'H2均价': st.column_config.NumberColumn(format="%,.1f"),
            })

        # 单价趋势
        st.subheader("Top 5 月度单价趋势")
        if HAS_PLOTLY:
            fig = go.Figure()
            for idx, p in enumerate(pv[:5]):
                prices = p.get('月度单价', [])
                if len(prices) == 12:
                    clean = [v if v and v > 0 else None for v in prices]
                    fig.add_trace(go.Scatter(
                        x=MONTHS, y=clean, name=p['客户'],
                        mode='lines+markers',
                        line=dict(color=COLORS[idx], width=2),
                        marker=dict(size=6),
                    ))
            fig.update_layout(**plotly_layout("月度单价走势（元）", 380))
            fig.update_yaxes(title_text="单价（元）")
            st.plotly_chart(fig, use_container_width=True)
        else:
            price_data = {}
            for p in pv[:5]:
                prices = p.get('月度单价', [])
                if len(prices) == 12:
                    price_data[p['客户']] = [v if v else None for v in prices]
            if price_data:
                st.line_chart(pd.DataFrame(price_data, index=MONTHS))

# ============================================================
# Tab 3: 预警中心
# ============================================================
with tabs[3]:
    alerts = results['流失预警']
    anomalies = results['MoM异常']

    if alerts:
        total_risk = sum(a['年度金额'] for a in alerts)
        high_alerts = [a for a in alerts if '高' in a['风险']]
        
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("预警客户", f"{len(alerts)}家")
        c2.metric("高风险", f"{len(high_alerts)}家", "需立即关注")
        c3.metric("风险金额", f"{total_risk:,.0f}万")
        c4.metric("占总营收", f"{total_risk/data['总营收']*100:.1f}%")

        st.subheader("🔴 流失风险排名")
        alert_df = pd.DataFrame(alerts)
        display_cols = [c for c in ['客户', '风险', '得分', '年度金额', '原因'] if c in alert_df.columns]
        if '年度金额' in alert_df.columns:
            alert_df['年度金额'] = pd.to_numeric(alert_df['年度金额'], errors='coerce').round(0)
        st.dataframe(alert_df[display_cols], use_container_width=True, hide_index=True,
            column_config={
                '年度金额': st.column_config.NumberColumn(format="%,.0f"),
                '得分': st.column_config.ProgressColumn(min_value=0, max_value=120, format="%d"),
            })

        # 预警客户月度走势
        st.subheader("预警客户月度走势")
        sel_alert = st.selectbox("选择", [a['客户'] for a in alerts], key='alert_sel')
        a_data = next((a for a in alerts if a['客户'] == sel_alert), None)
        if a_data and '月度趋势' in a_data:
            if HAS_PLOTLY:
                vals = a_data['月度趋势']
                fig = go.Figure()
                fig.add_trace(go.Bar(
                    x=MONTHS, y=vals, 
                    marker_color=[RED if v > 0 else "rgba(255,68,102,0.3)" for v in vals],
                    text=[f"{v:,.0f}" if v > 0 else "" for v in vals],
                    textposition="outside", textfont=dict(size=10),
                ))
                fig.update_layout(**plotly_layout(f"{sel_alert} — 月度走势（万元）", 350, False))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.bar_chart(pd.DataFrame({'月份': MONTHS, '金额': a_data['月度趋势']}).set_index('月份'), color=RED)
    else:
        st.success("🎉 无高风险预警")

    st.divider()
    st.subheader("⚡ 月度异常检测")
    st.caption("自动标记环比>30%或偏离均值2.5x的数据点")
    if anomalies:
        anom_df = pd.DataFrame(anomalies[:20])
        for col in ['当月', '上月', '月均']:
            if col in anom_df.columns:
                anom_df[col] = pd.to_numeric(anom_df[col], errors='coerce').round(0)
        st.dataframe(anom_df, use_container_width=True, hide_index=True)
    else:
        st.info("无显著异常")

# ============================================================
# Tab 4: 增长机会
# ============================================================
with tabs[4]:
    growth = results['增长机会']
    if growth:
        types = sorted(set(g['类型'] for g in growth))
        cols = st.columns(len(types))
        for i, t in enumerate(types):
            cnt = sum(1 for g in growth if g['类型'] == t)
            cols[i].metric(t, f"{cnt}个")

        st.divider()
        g_df = pd.DataFrame(growth)
        if '金额' in g_df.columns:
            g_df['金额'] = pd.to_numeric(g_df['金额'], errors='coerce').round(0)
        st.dataframe(g_df, use_container_width=True, hide_index=True,
            column_config={'金额': st.column_config.NumberColumn(format="%,.0f")})
    else:
        st.info("暂无显著增长信号")

# ============================================================
# Tab 5: 产品结构
# ============================================================
with tabs[5]:
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("产品类型 (FP/SP/PAD)")
        prod = results['产品结构']
        if prod:
            st.dataframe(pd.DataFrame(prod), use_container_width=True, hide_index=True)
            if HAS_PLOTLY:
                fig = go.Figure(data=[go.Pie(
                    labels=[p['类型'] for p in prod],
                    values=[p['全年实际'] for p in prod],
                    hole=0.45,
                    marker_colors=[CYAN, PURPLE, GREEN],
                    textinfo='label+percent', textfont=dict(size=12),
                )])
                fig.update_layout(**plotly_layout("", 320, False))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.bar_chart(pd.Series({p['类型']: p['全年实际'] for p in prod}), color=CYAN)

    with col2:
        st.subheader("订单模式 (CKD/SKD/CBU)")
        order = results['订单模式']
        if order:
            st.dataframe(pd.DataFrame(order), use_container_width=True, hide_index=True)
            if HAS_PLOTLY:
                fig = go.Figure(data=[go.Pie(
                    labels=[o['模式'] for o in order],
                    values=[o['全年数量'] for o in order],
                    hole=0.45,
                    marker_colors=[ORANGE, CYAN, PURPLE],
                    textinfo='label+percent', textfont=dict(size=12),
                )])
                fig.update_layout(**plotly_layout("", 320, False))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.bar_chart(pd.Series({o['模式']: o['全年数量'] for o in order}), color=PURPLE)

    # 计划 vs 实际
    st.divider()
    st.subheader("月度数量：计划 vs 实际")
    qs = data['数量汇总']
    if HAS_PLOTLY:
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=MONTHS, y=qs['月度计划'], name="计划",
            line=dict(color="rgba(100,100,180,0.5)", width=2, dash='dash'),
            mode='lines',
        ))
        fig.add_trace(go.Scatter(
            x=MONTHS, y=qs['月度实际'], name="实际",
            line=dict(color=GREEN, width=2.5),
            mode='lines+markers', marker=dict(size=6),
            fill='tonexty', fillcolor='rgba(0,204,102,0.08)',
        ))
        fig.update_layout(**plotly_layout("月度出货：计划 vs 实际", 380))
        fig.update_yaxes(title_text="台数")
        st.plotly_chart(fig, use_container_width=True)
    else:
        qty_df = pd.DataFrame({'月份': MONTHS, '计划': qs['月度计划'], '实际': qs['月度实际']}).set_index('月份')
        st.line_chart(qty_df)

# ============================================================
# Tab 6: 区域分析
# ============================================================
with tabs[6]:
    reg = results['区域洞察']

    c1, c2, c3 = st.columns(3)
    c1.metric("覆盖区域", f"{len(reg['详细'])}个")
    c2.metric("Top3集中度", f"{reg['Top3集中度']}%")
    c3.metric("HHI指数", f"{reg['赫芬达尔指数']}", "⚠️高度集中" if reg['赫芬达尔指数']>2500 else "")

    if reg['赫芬达尔指数'] > 2500:
        st.warning(f"⚠️ HHI={reg['赫芬达尔指数']}（>2500为高度集中），过度依赖单一市场")

    st.dataframe(pd.DataFrame(reg['详细']), use_container_width=True, hide_index=True)

    if HAS_PLOTLY:
        fig = go.Figure()
        regions = reg['详细']
        fig.add_trace(go.Bar(
            x=[r['区域'] for r in regions],
            y=[r['金额'] for r in regions],
            marker_color=[CYAN if i == 0 else "rgba(0,212,255,0.4)" for i in range(len(regions))],
            text=[f"{r['金额']:,.0f}" for r in regions],
            textposition="outside", textfont=dict(size=10),
        ))
        fig.update_layout(**plotly_layout("区域出货分布（万元）", 380, False))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.bar_chart(pd.Series({r['区域']: r['金额'] for r in reg['详细']}), color=CYAN)

# ============================================================
# Tab 7: 行业对标
# ============================================================
with tabs[7]:
    st.subheader("🌐 行业基准对标")
    st.caption("数据来源：IDC / Counterpoint / 公司年报")

    mp = benchmark['市场定位']
    st.markdown("#### 禾苗在ODM行业的位置")
    for k, v in mp.items():
        st.markdown(f"""<div class="insight-card"><h4>{k}</h4><p>{v}</p></div>""", unsafe_allow_html=True)

    st.divider()

    st.markdown("#### 竞争对标")
    cb = benchmark['竞争对标']
    comp_data = []
    for name in ['华勤', '闻泰', '龙旗', '禾苗']:
        comp_data.append({
            '公司': f"{'👉 ' if name=='禾苗' else ''}{name}",
            '营收(亿)': cb['营收'].get(name, '-'),
            '增速': cb['增速'].get(name, '-'),
            '毛利率': cb['毛利率'].get(name, '-'),
        })
    st.dataframe(pd.DataFrame(comp_data), use_container_width=True, hide_index=True)
    st.info(f"📊 客户集中度：{cb['客户集中度']}")

    st.divider()

    st.markdown("#### 核心客户外部情报")
    for v in benchmark['客户外部视角']:
        with st.expander(f"**{v['客户']}**", expanded=v['客户']=='HMD'):
            if '外部' in v: st.markdown(f"🌐 **外部趋势**：{v['外部']}")
            if '禾苗' in v: st.markdown(f"📊 **禾苗表现**：{v['禾苗']}")
            st.markdown(f"🎯 **判断**：{v['判断']}")
            if '根因' in v:
                st.error(f"🔍 **根因分析**：{v['根因']}")

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### 结构性风险")
        for r in benchmark['结构性风险']:
            with st.expander(f"🔴 {r['风险']}"):
                st.markdown(f"**行业**：{r['行业']}")
                st.markdown(f"**禾苗**：{r['禾苗']}")
                st.success(f"→ **建议**：{r['建议']}")
    with col2:
        st.markdown("#### 战略增长机会")
        for o in benchmark['战略机会']:
            with st.expander(f"🚀 {o['机会']}（{o['数据']}）"):
                st.markdown(f"**行业**：{o['行业']}")
                st.success(f"→ **行动**：{o['行动']}")

# ============================================================
# Tab 8: 预测
# ============================================================
with tabs[8]:
    st.subheader("🔮 2026年前瞻预测")

    t = forecast['总营收预测']
    c1, c2, c3 = st.columns(3)
    c1.metric("Q1 2026 乐观", f"{t['置信区间']['乐观(+15%)']:,.0f}万")
    c2.metric("Q1 2026 基准", f"{t['置信区间']['基准']:,.0f}万", "⬅️ 核心预测")
    c3.metric("Q1 2026 悲观", f"{t['置信区间']['悲观(-15%)']:,.0f}万")

    st.caption(f"参考：Q1 2025实际 {t['参考']['Q1_2025实际']:,.0f}万 | Q4 2025实际 {t['参考']['Q4_2025实际']:,.0f}万")

    with st.expander("预测方法详情"):
        for k, v in t['方法说明'].items():
            st.markdown(f"- **{k}**：{v}")

    st.divider()

    # 客户预测
    st.markdown("#### Top10 客户 Q1 预测")
    cpred = forecast['客户预测']
    cp_df = pd.DataFrame(cpred)
    for col in ['Q4实际', 'Q1预测']:
        if col in cp_df.columns:
            cp_df[col] = pd.to_numeric(cp_df[col], errors='coerce').round(0)
    st.dataframe(cp_df, use_container_width=True, hide_index=True,
        column_config={
            'Q4实际': st.column_config.NumberColumn(format="%,.0f"),
            'Q1预测': st.column_config.NumberColumn(format="%,.0f"),
        })

    st.divider()

    # 品类预测
    st.markdown("#### 业务类别 2026E")
    st.dataframe(pd.DataFrame(forecast['品类预测']), use_container_width=True, hide_index=True)

    st.divider()

    # 情景分析 — Plotly瀑布图
    st.markdown("#### 年度情景分析")
    scenarios = forecast['风险场景']
    
    if HAS_PLOTLY:
        names = list(scenarios.keys())
        values = [scenarios[n]['全年预测'] for n in names]
        colors_s = [GREEN, CYAN, ORANGE, RED]
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=[n.split('(')[0] for n in names], y=values,
            marker_color=colors_s,
            text=[f"{v/10000:.1f}亿" for v in values],
            textposition="outside", textfont=dict(size=13, color="#ccccee"),
        ))
        fig.update_layout(**plotly_layout("2026年度情景预测", 400, False))
        fig.update_yaxes(title_text="万元")
        st.plotly_chart(fig, use_container_width=True)
    
    cols = st.columns(4)
    for i, (name, sc) in enumerate(scenarios.items()):
        with cols[i]:
            st.metric(name.split('(')[0], f"{sc['全年预测']/10000:.1f}亿")
            st.caption(sc['假设'])

    st.divider()
    with st.expander("关键假设与局限"):
        for a in forecast['关键假设']:
            st.markdown(f"- {a}")

# ============================================================
# Tab 9: CEO备忘录
# ============================================================
with tabs[9]:
    st.subheader("✍️ 管理层战略备忘录")

    if ai_enabled and api_key:
        if st.button("🧠 用AI生成深度叙事", type="primary"):
            narrator = AINarrator(data, results, benchmark, forecast)
            with st.spinner("AI 正在分析... (约30秒)"):
                ai_text = narrator.generate(api_key, ai_provider.lower())
            st.markdown(ai_text)
            st.download_button("📥 下载AI分析", ai_text, "ai_memo.md", "text/markdown")
        else:
            st.info("👆 点击按钮生成AI深度分析，或查看下方内置版本")

    narrator = AINarrator(data, results, benchmark, forecast)
    memo = narrator._template_narrative()

    with st.expander("📄 内置战略备忘录（完整版）", expanded=not ai_enabled):
        st.markdown(memo)

# ============================================================
# Tab 10: 导出
# ============================================================
with tabs[10]:
    st.subheader("📥 报告导出")

    gen = ReportGeneratorV2(data, results)
    base_report = gen.generate()
    bench_section = generate_benchmark_section(benchmark)
    forecast_section = generate_forecast_section(forecast)
    narrator = AINarrator(data, results, benchmark, forecast)
    memo = narrator._template_narrative()

    footer = "\n---\n> MRARFAI 销售分析"
    if footer in base_report:
        parts = base_report.split(footer)
        full = parts[0] + bench_section + forecast_section + memo + footer + parts[1]
    else:
        full = base_report + bench_section + forecast_section + memo

    full = full.replace("Agent v2.0", f"Agent v{VERSION}").replace("智能分析系统 v2.0", f"智能分析系统 v{VERSION}")

    now = datetime.now().strftime('%Y%m%d')

    col1, col2, col3 = st.columns(3)
    with col1:
        st.download_button("📄 完整报告 (Markdown)", full,
            f"禾苗销售分析_{now}.md", "text/markdown", use_container_width=True)
    with col2:
        json_all = json.dumps({
            '分析': results, '行业': benchmark, '预测': forecast
        }, ensure_ascii=False, indent=2, default=str)
        st.download_button("📊 分析数据 (JSON)", json_all,
            f"analysis_{now}.json", "application/json", use_container_width=True)
    with col3:
        prompt = gen.generate_ai_prompt()
        st.download_button("🤖 AI Prompt", prompt,
            "ai_prompt.txt", "text/plain", use_container_width=True)

    st.divider()
    with st.expander("📖 报告预览"):
        st.markdown(full)

# ============================================================
# Tab 11: 用户反馈（Week 5-6 新增）
# ============================================================
with tabs[11]:
    st.subheader("💬 使用反馈")
    st.caption("您的反馈将直接帮助我们改进产品（KPI目标：满意度>80%）")

    with st.form("feedback_form", clear_on_submit=True):
        col1, col2 = st.columns([1, 2])
        with col1:
            user_name = st.text_input("您的姓名（可选）", placeholder="匿名")
            rating = st.slider("整体满意度", 1, 10, 7, help="1=非常不满意，10=非常满意")
        
        with col2:
            tab_options = ["总览", "客户分析", "价量分解", "预警中心", "增长机会", 
                          "产品结构", "区域分析", "行业对标", "预测", "CEO备忘录"]
            useful_tabs = st.multiselect("哪些分析模块对您最有帮助？", tab_options)
        
        pain_points = st.text_area("使用中遇到的问题或不满", placeholder="例如：数据加载慢、某个图表看不懂、缺少某个分析维度...")
        suggestions = st.text_area("改进建议", placeholder="例如：希望增加XX功能、希望报告格式改为XX...")
        
        submitted = st.form_submit_button("📨 提交反馈", type="primary", use_container_width=True)
        if submitted:
            path = save_feedback(
                rating=rating,
                useful_tabs=useful_tabs,
                pain_points=pain_points,
                suggestions=suggestions,
                user_name=user_name or "匿名",
            )
            st.success("✅ 感谢您的反馈！我们会尽快改进。")
            log_usage('feedback_submitted', f"rating={rating}")
    
    # 反馈汇总（管理员视角）
    st.divider()
    summary = get_summary()
    if summary['count'] > 0:
        with st.expander(f"📊 反馈汇总（共{summary['count']}条）"):
            c1, c2 = st.columns(2)
            c1.metric("平均满意度", f"{summary['avg_rating']:.1f}/10", 
                      "✅达标" if summary['avg_rating'] >= 8 else "⚠️需改进")
            c2.metric("累计反馈", f"{summary['count']}条")
            
            if summary['tab_votes']:
                st.markdown("**最受欢迎模块：**")
                for tab, count in list(summary['tab_votes'].items())[:5]:
                    st.progress(count / summary['count'], text=f"{tab}（{count}票）")
